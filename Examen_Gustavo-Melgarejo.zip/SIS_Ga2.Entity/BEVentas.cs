﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SIS_Ga2.Entity
{
    public class BEVentas
    {

        public int idcliente { get; set; }
        public int idusuario { get; set; }
        public string tipo_comprobante { get; set; }
        public string serie_comprobante { get; set; }
        public string num_comprobante { get; set; }
        public double impuesto { get; set; }
        public double total { get; set; }
        public string estado { get; set; }

        public int idarticulo { get; set; }
        public int cantidad { get; set; }
        public double precio { get; set; }
        public double descuento { get; set; }
        public int idcategoria { get; set; }
        public double Stock { get; set; }
       
    }

   }
