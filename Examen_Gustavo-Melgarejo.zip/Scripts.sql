USE [ventas]
GO
/****** Object:  StoredProcedure [dbo].[SP_INS_Registro_Ventas]    Script Date: 6/11/2020 15:35:30 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
create procedure [dbo].[SP_INS_Registro_Ventas]
@idcliente int,
@idusuario int,
@tipo_comprobante  varchar(20),
@serie_comprobante varchar(7),
@num_comprobante varchar(10),
@impuesto decimal(4,2),
@total decimal(11,2),
@estado varchar(1),
@idarticulo int,
@cantidad int,
@precio decimal(11,2),
@descuento  decimal(11,2)
as

DECLARE @Idventa int

insert into  venta
		(
		[idcliente],
		[idusuario],
		[tipo_comprobante],
		[serie_comprobante],
		[num_comprobante],
		[fecha_hora],	
		[impuesto],
		[total],
		[estado]
		)
values

		(
		@idcliente,
		@idusuario,
		@tipo_comprobante,
		@serie_comprobante,
		@num_comprobante,
		GETDATE(),			
		@impuesto,
		@total,
		@estado

		)

SELECT @idventa=@@IDENTITY 

insert into  [dbo].[detalle_venta]
([idventa],
[idarticulo],
[cantidad],
[precio],
[descuento])
values (@idventa,@idarticulo,@cantidad,@precio,@descuento)

GO
/****** Object:  StoredProcedure [dbo].[SP_SEL_Stock_Articulo]    Script Date: 6/11/2020 15:35:30 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE procedure [dbo].[SP_SEL_Stock_Articulo]
@idarticulo int,
@idcategoria int

as

SELECT Stock  FROM [articulo]
where idarticulo=@idarticulo and idcategoria=idcategoria

GO
/****** Object:  StoredProcedure [dbo].[SP_UPD_Stock_Articulos]    Script Date: 6/11/2020 15:35:30 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE procedure [dbo].[SP_UPD_Stock_Articulos]
@idarticulo int,
@idcategoria int,
@cantidad int
as

DECLARE @varStock AS INT

SELECT @varStock=Stock  FROM [articulo]
where idarticulo=@idarticulo and idcategoria=idcategoria

update [dbo].[articulo]
set
Stock=@varStock-@cantidad
where idarticulo=@idarticulo and idcategoria=idcategoria
GO
