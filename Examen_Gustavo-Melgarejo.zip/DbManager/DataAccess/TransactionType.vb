
Namespace DataObjects

    Public Enum TransactionType

        Automatic = 1
        Manual = 2

    End Enum

    Public Enum ParameterOrientation
        Parameter_IN = 1
        Parameter_OUT = 2
    End Enum

End Namespace
