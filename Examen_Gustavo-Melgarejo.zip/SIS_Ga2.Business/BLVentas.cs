﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SIS_Ga2.Entity;
using SIS_Ga2.DataAccess;

namespace SIS_Ga2.Business
{
    public class BLVentas
    {
        //Metodo de Logica de datos : Registrar para la tabla cliente
        public int RegistrarVenta(BEVentas objEntidad)
        {
            DACVentas objDAO = new DACVentas();
            return objDAO.RegistrarVenta(objEntidad);
        }
        public bool ActualizarStock(BEVentas objEntidad)
        {
            DACVentas objDAO = new DACVentas();
            return objDAO.ActualizarStock(objEntidad);
        }


          public List<BEVentas> ValidarStock(int idarticulo, int idcategoria)
        {
            DACVentas objDAO = new DACVentas();
            return objDAO.ValidarStock(idarticulo, idcategoria);
        }

    }
}
