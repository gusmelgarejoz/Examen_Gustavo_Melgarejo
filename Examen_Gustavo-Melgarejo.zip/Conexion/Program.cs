﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Data;
using System.Configuration;
using SIS_Ga2.Business;
using SIS_Ga2.Entity;
using System.Net;
using log4net;
using System.Threading;

namespace Conexion
{
    class Program
    {
        private static readonly ILog Log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        static void Main(string[] args)
        {
            List<BEVentas> lobjBEVentas = new List<BEVentas>();
            BEVentas objDBE = new BEVentas();
            BLVentas objDBL = new BLVentas();
            List<BEVentas> lstBEVentas = new List<BEVentas>();
            objDBE.idcliente = 1;
            objDBE.idusuario = 1;
            objDBE.tipo_comprobante = "Boleta";
            objDBE.serie_comprobante = "001";
            objDBE.num_comprobante = "0000001";
            objDBE.impuesto = 0;
            objDBE.total = 650;
            objDBE.estado = "1";
            objDBE.idarticulo = 1;
            objDBE.idcategoria = 1;
            objDBE.cantidad = 13;
            objDBE.precio = 4.5;
            objDBE.descuento = 1;
            int resultado;
            double stock = 0;

            lstBEVentas = objDBL.ValidarStock(objDBE.idarticulo, objDBE.idcategoria);
            foreach (BEVentas item in lstBEVentas)
            {
                stock = item.Stock;

            }
            if (stock > 0)
            {

                resultado = objDBL.RegistrarVenta(objDBE);
                if (resultado == 1)
                {
                    objDBL.ActualizarStock(objDBE);
                }
                else
                {
                    Log.Info("Error en el registro de Venta");
                }


            }
            else
            {
                Log.Info("No hay Stock");

            }

        }

    }
}


