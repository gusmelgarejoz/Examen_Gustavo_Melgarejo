﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;



namespace SIS_Ga2.DataAccess
{
   public class ConexionDB
    {
        private static ConexionDB objConexionDB = null;
        private SqlConnection conSQL;

        private ConexionDB()
        {
            string tipoBd = ConfigurationManager.AppSettings["EjecutarBD"].ToString();

            switch (tipoBd)
            {
                case "1":
                    conSQL = new SqlConnection(ConfigurationManager.AppSettings["Sql"].ToString());
                    break;
                
            }
           
        }

        public static ConexionDB saberEstadoSQL()
        {
            if (objConexionDB == null)
            {
                objConexionDB = new ConexionDB();

            }
            return objConexionDB;
        }



        public SqlConnection getConSQL()
        {
            return conSQL;
        }

        public void closeDBSQL()
        {
            objConexionDB = null;
        }

        // MYSQL
       
        public void closeDBMySQL()
        {
            objConexionDB = null;
        }

        // PostGre
       
        public void closeDBPostgre()
        {
            objConexionDB = null;
        }


       

    }
}
