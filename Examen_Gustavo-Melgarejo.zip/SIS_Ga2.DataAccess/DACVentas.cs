﻿using DbManager.DataObjects;
using SIS_Ga2.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
namespace SIS_Ga2.DataAccess
{
    public class DACVentas
    {
        public int RegistrarVenta(BEVentas objEntidad)
        {
           
            int resultado = 0;
            SqlManager objSql = new SqlManager(ConfigurationManager.AppSettings["Sql"].ToString());
            Parameter param = new Parameter();
            param.Add("@idcliente ", objEntidad.idcliente);
            param.Add("@idusuario", objEntidad.idusuario);
            param.Add("@tipo_comprobante", objEntidad.tipo_comprobante);
            param.Add("@serie_comprobante", objEntidad.serie_comprobante);
            param.Add("@num_comprobante", objEntidad.num_comprobante);
            param.Add("@impuesto", objEntidad.impuesto);
            param.Add("@total", objEntidad.total);
            param.Add("@estado", objEntidad.estado);
            param.Add("@idarticulo", objEntidad.idarticulo);
            param.Add("@cantidad", objEntidad.cantidad);
            param.Add("@precio", objEntidad.precio);
            param.Add("@descuento", objEntidad.descuento);
            

            try
            {
              
                objSql.ExecuteNonQuery("SP_INS_Registro_Ventas", param);
                resultado = 1;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return resultado;
        }

        public bool ActualizarStock(BEVentas objEntidad)
        {
            //SqlManager objSql = new SqlManager();
            SqlManager objSql = new SqlManager(ConfigurationManager.AppSettings["Sql"].ToString());
            bool resultado = false;
            Parameter param = new Parameter();
            param.Add("@idarticulo", objEntidad.idarticulo);
            param.Add("@idcategoria", objEntidad.idcategoria);
            param.Add("@cantidad", objEntidad.cantidad);


            try
            {  
                objSql.ExecuteNonQuery("SP_UPD_Stock_Articulos", param);
                resultado = true;
            }
            catch (Exception)
            {
                //afilogDAO.Save(0, 0, "Sincronizar cliente", "registrar", ex);
                resultado = false;
            }
            //Rutina de Guardado en Log 
            return resultado;
        }

        public List<BEVentas> ValidarStock(int idarticulo, int idcategoria)
        {
            try
            {
             
                Parameter param = new Parameter();
                param.Add("@idarticulo", idarticulo);
                param.Add("@idcategoria", idcategoria);
             
                SqlManager objSql = new SqlManager(ConfigurationManager.AppSettings["Sql"].ToString());
                List<BEVentas> lista = objSql.getStatement<BEVentas>("SP_SEL_Stock_Articulo", param);
                return lista;
            }
            catch (Exception ex)
            {
                //Rutina de Guardado en Log 
                //afilogDAO.Save(0, 0, "CatalogoDAO", "GetCatalogoToCombo", ex);
                throw ex;
            }
        }
    }
}
